package notasAlumno;

public class Alumno { 
	private String nombre; 
	private int telefono; 
	private int edad; 
    private int nota1; 
    private int nota2; 
    private int nota3; {
    
    nota1 = 0 + (int)(Math.random());
    nota2 = 0 + (int)(Math.random()); 
    nota3 = 0 + (int)(Math.random());
    
    
} 

}